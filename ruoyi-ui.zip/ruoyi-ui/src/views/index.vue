<template>
  <div class="dashboard-editor-container">
    <el-row>
      <el-col :span="8">
        <el-card class="box-card" style="background-color: red">
          <div slot="header" class="clearfix">
            <span>卡片名称</span>
          </div>
          78
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="box-card" style="background-color: red">
          <div slot="header" class="clearfix">
            <span>卡片名称2</span>
          </div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="box-card" style="background-color: red">
          <div slot="header" class="clearfix">
            <span>卡片名称3</span>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
          <div class="echart" id="mychart"></div>
      </el-col>
      <el-col :span="12">
        <div class="echart" id="mychart2"></div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
const echarts = require('echarts')
export default {
  name: 'Index',
  components: {
  },
  data() {
    return {
      xData: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], //横坐标
      yData: [23, 24, 18, 25, 27, 28, 25], //人数数据
      taskDate: [10, 11, 9, 17, 14, 13, 14],
    }
  },
  mounted() {
    this.initEcharts();
  },
  methods: {
    initEcharts() {
      // 多列柱状图
      const mulColumnZZTData = {
        xAxis: {
          data: this.xData
        },
        // 图例
        legend: {
          data: ["人数", "任务数"],
          top: "0%"
        },
        yAxis: {},
        series: [
          {
            type: "bar", //形状为柱状图
            data: this.yData,
            name: "人数", // legend属性
            label: {
              // 柱状图上方文本标签，默认展示数值信息
              show: true,
              position: "top"
            }
          },
          {
            type: "bar", //形状为柱状图
            data: this.taskDate,
            name: "任务数", // legend属性
            label: {
              // 柱状图上方文本标签，默认展示数值信息
              show: true,
              position: "top"
            }
          }
        ]
      };
      const myChart = echarts.init(document.getElementById("mychart"));
      myChart.setOption(mulColumnZZTData);
      //随着屏幕大小调节图表
      window.addEventListener("resize", () => {
        myChart.resize();
      });
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;
}
</style>
